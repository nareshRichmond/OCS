package com.wipro.ocs.action;

import com.wipro.ocs.dao.UserDAO;

public class UserAction 
{
String userId,firstName,lastName,gender,address;
int age, phoneNumber,loginStatus;
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public int getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(int phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public int getLoginStatus() {
	return loginStatus;
}
public void setLoginStatus(int loginStatus) {
	this.loginStatus = loginStatus;
}

public String signUpExecute()
{
	
	UserDAO obj= new UserDAO(); 
	String val=obj.signUp(firstName, lastName,age, gender, address, phoneNumber,loginStatus);
	
	return val;
}


}
