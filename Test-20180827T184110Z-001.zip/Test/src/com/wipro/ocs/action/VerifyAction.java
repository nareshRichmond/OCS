package com.wipro.ocs.action;
import com.wipro.ocs.dao.*;
public class VerifyAction {

String userType,userId,password,newPassword;

public String getNewPassword() {
	return newPassword;
}

public void setNewPassword(String newPassword) {
	this.newPassword = newPassword;
}

public String getUserType() {
	return userType;
}

public void setUserType(String userType) {
	this.userType = userType;
}

public String getUserId() {
	return userId;
}

public void setUserId(String userId) {
	this.userId = userId;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String loginExecute()
{
	boolean valid=false;
	VerifyDAO obj= new VerifyDAO(); 
	valid=obj.login(userId, password);
	
		if(valid==true && userId.equals("AD0001"))
		{
		return "admin";
		}
		else if(valid==true && userId.equals("RE0001"))
		{
			return "reporter";
		}
		else if(valid==true)
		{
			return "user";
		}
			else
			{
				return "error";
			}}
	
}


