/* 
* <Copyright information>
*
* <Customer specific copyright notice (if any) >
*
* <File Name>
*
* <Short Description>
*
* <Version Number > 
*
* <Created Date in dd mmm yyyy format>
*
* <Modification History>
*/

package com.wipro.ocs.action;

public class AdminAction {
	String doctorId,doctorName,dOB,dOJ,gender,qualification,specialization;
	int experience,contactNumber,doctorStatus;
	/**
	 * @return the doctorId
	 */
	public String getDoctorId() {
		return doctorId;
	}
	/**
	 * @param doctorId the doctorId to set
	 */
	public void setDoctorId(String doctorId) {
		this.doctorId = doctorId;
	}
	/**
	 * @return the doctorName
	 */
	public String getDoctorName() {
		return doctorName;
	}
	/**
	 * @param doctorName the doctorName to set
	 */
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	/**
	 * @return the dOB
	 */
	public String getDOB() {
		return dOB;
	}
	/**
	 * @param dOB the dOB to set
	 */
	public void setDOB(String dOB) {
		this.dOB = dOB;
	}
	/**
	 * @return the dOJ
	 */
	public String getDOJ() {
		return dOJ;
	}
	/**
	 * @param dOJ the dOJ to set
	 */
	public void setDOJ(String dOJ) {
		this.dOJ = dOJ;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the qualification
	 */
	public String getQualification() {
		return qualification;
	}
	/**
	 * @param qualification the qualification to set
	 */
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	/**
	 * @return the specialization
	 */
	public String getSpecialization() {
		return specialization;
	}
	/**
	 * @param specialization the specialization to set
	 */
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	/**
	 * @return the experience
	 */
	public int getExperience() {
		return experience;
	}
	/**
	 * @param experience the experience to set
	 */
	public void setExperience(int experience) {
		this.experience = experience;
	}
	/**
	 * @return the contactNumber
	 */
	public int getContactNumber() {
		return contactNumber;
	}
	/**
	 * @param contactNumber the contactNumber to set
	 */
	public void setContactNumber(int contactNumber) {
		this.contactNumber = contactNumber;
	}
	/**
	 * @return the doctorStatus
	 */
	public int getDoctorStatus() {
		return doctorStatus;
	}
	/**
	 * @param doctorStatus the doctorStatus to set
	 */
	public void setDoctorStatus(int doctorStatus) {
		this.doctorStatus = doctorStatus;
	}
	
		}


	


