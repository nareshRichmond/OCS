package com.wipro.ocs.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class UserDAO {
	

	
	public Connection getConnection() throws Exception
	{

		Class.forName("oracle.jdbc.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE", "hr", "HR");
		
		return con;
	}
	
	public String signUp(String firstName, String lastName, int age, String gender, String address, int phoneNumber, int loginStatus) 
	{
		
		try
		{
		Connection con=getConnection();
		System.out.println("Connection established successfully");
		PreparedStatement ps=con.prepareStatement("insert into ocs_user_details_tb values('us'||userid.nextval,?,?,?,?,?,?,1)");
		ps.setString(1,firstName);
		ps.setString(2,lastName);
		ps.setInt(3,age);
		ps.setString(4,gender);
		ps.setString(5,address);
		ps.setInt(6,phoneNumber);
		ps.executeUpdate();
	
		
		
		PreparedStatement ps1=con.prepareStatement("insert into ocs_authentication_tb values('u','us'||userid.currval,'us'||userid.currval)");
		ps1.executeUpdate();
		System.out.println("Succesfully inserted!!!");
		
		Statement s=con.createStatement();
		ResultSet rs=s.executeQuery("select userid.currval from dual");
		
		con.close();
		return rs.getString(1);
	
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "error";
		}
	}
}
