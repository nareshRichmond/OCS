package com.wipro.ocs.dao;

import java.sql.*;

public class VerifyDAO {
	//Connection conn
		public Connection getConnection() throws Exception
		{
		
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE", "hr", "HR");
			
			return con;
		}
		public boolean login(String userId,String password)
		{
			ResultSet rs=null;
			try
			{				
			Connection con=getConnection();
			String qry="select * from ocs_authentication_tb where fk_user_id=? and nn_password=?";
			PreparedStatement ps=con.prepareStatement(qry);
			ps.setString(1,userId);
			ps.setString(2,password);
		
			rs=ps.executeQuery();
		
			if(rs.next())
			{
			
				return true;
				
			}
			else
			{
				//System.out.println("hello");
				return false;
			}
			}
			catch(Exception e)
			{
				//System.out.println("hi");
				System.out.println(e);
				return false;
			}
			
		}
}
