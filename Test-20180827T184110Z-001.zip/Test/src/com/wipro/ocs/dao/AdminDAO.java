package com.wipro.ocs.dao;

public class AdminDAO 
{

}
